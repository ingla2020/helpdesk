package com.example.omnichannelticketsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmnichannelTicketSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
