package com.example.omnichannelticketsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmnichannelTicketSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmnichannelTicketSystemApplication.class, args);
	}

}
